function passCheck();
if (pass1.value.length >0 && pass2.value.length> 0){
    if (pass1.value === pass2.value) {
        error_div.innerHTML = "";
        pass1.setCustomValidity('');
        pass2.setCustomValidity('');
        return true;
    } else {
        error_div.innerHTML= "Passwords do not Match";
        pass1.setCustomValidity('moo!!!');
        pass2.setCustomValidity('choo!!!');
        return false;
    }
}
function revealPasswords() {
    if(pass1.getAttribute('type') === 'text') {
        pass1.setAttribute('type', 'password');
        pass2.setAttribute('type', 'password');
        eye.setAttribute('class' , 'fas fa-eye-slash');
    }else {
        pass1.setAttribute('type', 'text');
        pass2.setAttribute('type', 'text');
        eye.setAttribute('class' , 'fas fa-eye');
    }
}


function formcheck() {
    var errorStr ='';
    if(passCheck() === false) {
        errorStr += 'Passwords do not match'
    }
    if (fname.checkValidity() === false){
        fname.setCustomValidity('error')
        errorStr +='Please insert a Valid First Name';
    } else {
        fname.setCustomValidity('');
    }
    if (lname.checkValidity() === false) {
        lname.setCustomValidity('error');
        errorStr += 'Please insert a valid Surname'
    } else {
        lname.setCustomValidity('');
    }
    error_div.innerHTML = errorStr;
}
